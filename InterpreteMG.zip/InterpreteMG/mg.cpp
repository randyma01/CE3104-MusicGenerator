
#include "mg.h"

//Archivos donde la informacion
std::ofstream instrFile;
std::ifstream tempFunc; //temporal
std::ofstream errorFile;
std::ofstream tempFileFunc; //temporal

//Variables Strings
std::string nameProcess;
std::string nombreVariable;
std::string currentProcess;
std::string loopIniComp;

//Booleanos para controlar los flujos de escrituras de datos
bool inFunc = false;
bool inLoop = false;
bool inEnCaso = false;
bool inPrincipal = false;

//Vectores para las variables  y sus valores
std::vector<std::string>   procedimientos; 	 
std::vector<std::string>   variables;
std::vector<int>  		   valores;

//Variables Int
int valorVariable;
int posVar;
int lengthNameProcess;

//Valores de los tiempos
std::string negra = "NEGRA";
std::string blanca = "BLANCA";
std::string corchea = "CORCHEA";
std::string semicorchea = "SEMI"; 
std::string silencio = "SILE";

//Protipos o Firmas de las Funciones
void masMas();
void menosMenos();
bool vectorVariables(std::string name);
bool inVector(std::string name);
int loopFunc();
std::string notasTiempo(std::string tipo);
int iniCompFunc();   
int enCasoFunc();
void defFunc();
void setFunc();
int ejecuteFunc(std::string tempName);
int processFunc();
int principalFunc();


//Funciones

/*
Funcion para accion ++
*/
void masMas(){
    valorVariable++;
}

/*
Funcion para accion--
*/
void menosMenos(){
    valorVariable--;
}

/*
Funcion para manejar y buscar las variables 
declaradas en un vector general
*/
bool vectorVariables(std::string name){
	int lengthVector = variables.size();
	
	for(int i = 0; i < lengthVector; i++){
		if (variables[i] == name) {
			posVar = i;
			return true;
		}
	}
	return false;
}

/*
Funcion para indicar si el nombre de un "Proceso" a ejecutar
esta declaro previamente
si no lo esta retorna false
si esta retorna true
*/
bool inVector(std::string name){
	int lengthVector = procedimientos.size();	
	for(int i = 0; i < lengthVector; i++){
		if (procedimientos[i] == name) {
			return true;
		}
	}
	return false;
}


/*
Funcion para el proceso "Loop"
Retorna 0 si esta correcto o no hay nada escrito en el
Retorna -1 si hay error
*/
int loopFunc(){

	int cantidadCiclos;
	int numeroValorInicial;
	int numeroIncremento; 
	std::string tempLoop;
	int loopToken;
	loopToken = yylex();
	if(loopToken == PARENTESIS_IZQ){

		int tokenValorInicial = yylex();
		numeroValorInicial = atoi(yytext); //valor inicial

		int coma1 = yylex();
		
		int tokenIncremento = yylex();
		numeroIncremento = atoi(yytext); // valor del incremento del ciclo

		coma1 = yylex();

		int tokenValorMaximo = yylex();
		int numeroValorMaximo = atoi(yytext); // valor del valor maximo del loop

		coma1 = yylex();
		
		int tokenRepeticion = yylex();
		int numeroRepeticion = atoi(yytext); //valor de repeticiones del ciclo
		
		coma1 = yylex();

		cantidadCiclos = numeroValorMaximo * numeroRepeticion; //numero total de las repeticiones por hacer
		
		int tokenVariable = yylex();
		std::string nameVar = yytext;

		if(vectorVariables(nameVar)){
			int cierraLoop = yylex();
			if (cierraLoop == PARENTESIS_DER){

			}else{
				errorFile << "Syntax ERROR in line: " << yylineno <<   " Expect to close the LOOP with ')'. \n";
				errorFile.close();
				return -1;
			}
		}else{
			errorFile << "Syntax ERROR in line: " << yylineno <<   "Variable does not exist in this scope. \n";
			errorFile.close();
			return -1;
		}
		
	}
	else{
		errorFile << "Syntax ERROR in line: " << yylineno <<   " Expect to start with '(' \n";
		errorFile.close();
		return -1;
	}
	
	int nextToken = yylex();
	if (nextToken != INILOOP){
		errorFile << "Syntax ERROR in line: " << yylineno <<   " Expect to start with 'IniLoop' \n";
		errorFile.close();
		return -1;
	}else{
		nextToken = yylex();
		if (nextToken != FINLOOP){
			while(true){
				nextToken = yylex();
				if (nextToken == FINLOOP){
					break;
				}
				if (nextToken == 0){
					errorFile << "Syntax ERROR in line: " << yylineno <<   " Finish with  'FinLoop' \n";
					errorFile.close();
					return -1;
				}
				if (nextToken == INICOMP){
					if (iniCompFunc() == 0){
						break;
					}
					else{
						return -1;
					}
				}
				else{
					if(nextToken == LOOP){
						if(loopFunc() == 0){
							break;
						}else{
							return -1;
						};
					}
					if(nextToken == DEF){
						defFunc();
						break;
					}
					if(nextToken == SET){
						setFunc();
						break;
					}
					if(nextToken == NOTA){
						errorFile << "Syntax ERROR in line: " << yylineno <<   "Expect to start with 'IniComp' \n";
							errorFile.close();
							return -1;
					}

				}
			}
			printf("hay un loop!!!, valor inicial: %d, cantidadMaxima: %d, incremeno: %d\n",
			 		numeroValorInicial, cantidadCiclos, numeroIncremento);
			for(int i = numeroValorInicial; i<cantidadCiclos; i+=numeroIncremento){
				if(inFunc){
					tempFileFunc << loopIniComp;
				}
				else{
					instrFile << tempLoop;
				}
			}
			return 0;
		}
		else{
			return 0;
		}
	}

}

/*
Funcion para el proceso "notas"
Escribe la nota con el tiempo respectivo
a para el piano.
*/
std::string notasTiempo(std::string tipo){
	int ctoken;
	ctoken = yylex();
	std::string tempNotas;
	if (ctoken == NOTA){ 
		tempNotas =yytext + tipo + "|";
		return tempNotas; 
	}
	if(ctoken == NOTA_SOSTENIDA){
		tempNotas =yytext + tipo + "|";
		return tempNotas; 
	}
	if(ctoken == ACORDE_MAYOR){
		tempNotas =yytext + tipo + "|";
		return tempNotas; 
	}
	if(ctoken == ACORDE_MAYOR_SOSTENIDO){ 
		tempNotas =yytext + tipo + "|";
		return tempNotas; 
	}
	if(ctoken == ACORDE_MENOR){
		tempNotas =yytext + tipo + "|";
		return tempNotas; 
	}
	if(ctoken == ACORDE_MENOR_SOSTENIDO){ 
		tempNotas =yytext + tipo + "|";
		return tempNotas; 
	}
	else{ errorFile << "Syntax ERROR: no note after time. Line: " + yylineno; }
}

/*
Funcion para para el proceso de "IniComp"
Es un ciclo repetitvo para los casos de acciones
*/
int iniCompFunc(){
	int nextToken;
	std::string informacionTemporal;
	while(true){
		nextToken = yylex();
		if(nextToken == FINCOMP){
			break;
		}
		if(nextToken == 0){
			errorFile << "Syntax ERROR in line: " << yylineno <<   " Finish with  'FinComp' \n";
			errorFile.close();
			return -1;
		}
		switch (nextToken){
			case BLAK:
				informacionTemporal += notasTiempo(blanca);
				break;
			case NEG:
				informacionTemporal += notasTiempo(negra);
				break;
			case SCORCH:
				informacionTemporal += notasTiempo(semicorchea);
				break;
			case CORCH:
				informacionTemporal += notasTiempo(corchea);
				break;
		}

	}
	if (inFunc){
		loopIniComp =  informacionTemporal;
	}else{
		instrFile << informacionTemporal;
	}
	informacionTemporal.clear();	
	return 0;
}

/*
Metodo para el proceso "EnCaso"
Retorna 0 si esta correcto 
Retorna -1 si hay error o no hay nada escrito en el
*/
int enCasoFunc(){
	int casosToken = yylex();
	if(casosToken == PARENTESIS_IZQ){
		
		int valorV = yylex();
	
		std::string nameVariable = yytext;
		if(vectorVariables(nameVariable)){
			yylex();
			
			int operador = yylex();
			
			yylex();
			
			int valor = yylex();
			
			yylex();

			int parentesisDer = yylex();
		}
		else{
			errorFile << "Syntax ERROR in line: " << yylineno <<   " Variable does not exist in this scope.'(' \n";
			errorFile.close();
			return -1;
		}
	}
	else{
		errorFile << "Syntax ERROR in line: " << yylineno <<   " Expect to start with '(' \n";
		errorFile.close();
		return -1;
	}

	int nextToken = yylex();
	if (nextToken != ENTONCES){
		errorFile << "Syntax ERROR in line: "	 << yylineno <<   " Expect to start with 'Entonces.' \n";
		errorFile.close();
		return -1;
	}else{
		while(true){
			nextToken = yylex();
				if (nextToken == CONTRARIO){
					break;
				}
				if (nextToken == 0){
					errorFile << "Syntax ERROR in line: " << yylineno <<   " Must have a 'Contrario' \n";
					errorFile.close();
					return -1;
				}
				if (nextToken == ENCASO){
					if (enCasoFunc() == 0){
						return 0;
					}else{
						return -1;
					}
				}
				if (nextToken == LOOP){
					if (loopFunc() == 0){
						return 0;
					}else{
						return -1;
					}
				}
				if (nextToken == DEF){
					defFunc();
					break;
				}
				if (nextToken == SET) {
					setFunc();
					break;
				}
				if (nextToken == EJECUTE){
					yylex();
					nameProcess = yytext; // nameProcess.c_str(); //string to char *
					if( ejecuteFunc(nameProcess) == 0 ){
						break;
					}else{
						return -1;
					}
				}

				if (nextToken == INICOMP){
					if (iniCompFunc() == 0){
						break;
					}
					else{
						return -1;
					}
				}
	
			}	
		while(true){
			nextToken = yylex();
				if (nextToken == FINENCASO){
					break;
				}
				if (nextToken == 0){
					errorFile << "Syntax ERROR in line: " << yylineno <<   " Must have a 'FinCaso' \n";
					errorFile.close();
					return -1;
				}
				if (nextToken == ENCASO){
					if (enCasoFunc() == 0){
						return 0;
					}else{
						return -1;
					}
				}
				if (nextToken == LOOP){
					if (loopFunc() == 0){
						return 0;
					}else{
						return -1;
					}
				}
				if (nextToken == DEF){
					defFunc();
					break;
				}
				if (nextToken == SET) {
					setFunc();
					break;
				}
				if (nextToken == EJECUTE){
					yylex();
					nameProcess = yytext; // nameProcess.c_str(); //string to char *
					if( ejecuteFunc(nameProcess ) == 0 ){
						break;
					}else{
						return -1;
					}
				}
				if (nextToken == INICOMP){
					if (iniCompFunc() == 0){
						break;
					}
					else{
						return -1;
					}
				}
			}
		}
} 

/*
Funcion para la accion de "def"
crear una variable y/o asignarle un valor
*/
void defFunc(){
	yylex();
    nombreVariable = yytext;
	variables.push_back(nombreVariable);
	nombreVariable.clear();
    yylex();
    valorVariable = atoi(yytext);
	valores.push_back(valorVariable);
}

/*
Funcion para la accion de "set"
asignar un valor previamente
creada
*/
void setFunc(){
    yylex();
	std::string nameVar = yytext;
     if(vectorVariables(nameVar)){
         yylex();
         valorVariable = atoi(yytext);
		 valores[posVar] = valorVariable;
     }else{
		errorFile << "Syntax ERROR in line: " << yylineno << " Variable does not exist in this scope.\n";
		errorFile.close();
		exit(-1);
         
     }
}

/*
Funcion para la accion "Ejecutar"
Ejecuta las funciones o procedimientos
creados 
*/
int ejecuteFunc(std::string tempName){
	if (inVector(tempName)){
		std::string tempNameFile = tempName + ".txt";
		tempFunc.open(tempNameFile.c_str());
		char output[1000000];
		if (tempFunc.is_open()) {
			while (!tempFunc.eof()) {
				tempFunc >> output;
			}
		}
		tempFunc.close();
		if(inFunc){
			//tempFileFunc.open(currentProcess.c_str());
			tempFileFunc << output;
		}else{
			instrFile << output;
		}
		return 0;
	}else{
		errorFile << "Syntax ERROR in line: " << yylineno << ". " << tempName << " not declared!\n";
		errorFile.close();
		return -1;
	}
}

/*
Funcion para el leer "Procesos" declarados
Retorna 0 si esta correcto 
Retorna -1 si hay error o no hay nada escrito en el
*/
int processFunc(){
	int currentToken = yylex();
	if (currentToken == INICIO){
		while(true){
			currentToken =  yylex();
			//termina el ciclo cuando encuentra el token Final "Proceso"
			if (currentToken ==  FINAL){
				return 0;
			}
			//muestra error si no encuentra  el token Final
			if (currentToken == 0){
				errorFile << "Syntax ERROR in line: " <<  (yylineno - 1) <<   " Finish with  'Fin' 'Process'\n";
				errorFile.close();
				return -1;
			}
			switch (currentToken){
				case INICOMP:

					if (currentToken == INICOMP){
						inFunc = true;
						if (iniCompFunc() == 0){
							tempFileFunc << loopIniComp;
							inFunc = false;
							break;
						}
						else{
							return -1;
						}
					}
				case LOOP:
					inFunc = true;
					if(loopFunc() == 0){
						break;
					}else{
						return -1;
					};
				case ENCASO:
					inEnCaso = true;
					inFunc = true;
					if(enCasoFunc() == 0){
						inEnCaso = false;
						inFunc = false;
						break;
					}else{
						return -1;
					};
				case EJECUTE:
					yylex();
					nameProcess = yytext; // nameProcess.c_str(); //string to char *
					inFunc = true;
					if( ejecuteFunc(nameProcess) == 0 ){
						inFunc = false;
						break;
					}else{
						return -1;
					}
				case DEF:
					defFunc();
					break;
				case SET:
					setFunc();
					break;
			}
		}
	}
	else{
		errorFile << "Syntax ERROR in line: " <<  (yylineno - 1) <<   " Finish with  'Fin' 'Process'\n";
		errorFile.close();
		return -1;
	}	
}


/*
Metodo para el proceso "Principal"
Retorna 0 si esta correcto 
Retorna -1 si hay error o no hay nada escrito en el
*/
int principalFunc(){
	while(true){
		int currentToken = yylex();
		/*
		si encuentra FinMusica --> no hay nada en Principal
		*/
		if (currentToken ==  FINMUSICA){
			return -1;
		}
		//caso para cuando se llame "Ejecute Proceso"
		if (currentToken == EJECUTE){
			int nextToken = yylex();
			std::string tempName;
			tempName = yytext;
			if (inVector(tempName)){
				std::string nameFileFunc;
				nameFileFunc = tempName + ".txt";
				tempFunc.open(nameFileFunc.c_str());
				char output[1000000];
				if (tempFunc.is_open()) {
					while (!tempFunc.eof()) {
						tempFunc >> output;
					}
				}
				tempFunc.close();
				instrFile << output;
				return 0;
			}else{
				errorFile << "Syntax ERROR in line: " << yylineno << ". " << tempName << " not declared!\n";
				errorFile.close();
				return -1;
			}
		}

		//caso para llamar "loop" desde "Principal"
		if (currentToken == LOOP){
			inFunc = false;
			if (loopFunc() == 0){
				return 0;
			}else{
				return -1;
			}
		}

		//caso para llamar "Def" desde "Principal"
		if (currentToken == DEF){
			defFunc();
		}
		//caso para llamar "SET" desde "Principal"
		if (currentToken == SET){
			setFunc();
		}
		//caso para llamar "IniComp" desde 'Principal'
		if (currentToken == INICOMP){
			inPrincipal = true;
			if (iniCompFunc() == 0){
				inPrincipal = false;
				break;
			}
			else{
				return -1;
			}	
		}
	}
}

int main(void){
	yyin = fopen("source_code.mg", "rt");
	//crear los archivos de salida
	errorFile.open ("errores.txt");
	instrFile.open ("instrucciones.txt");

	int vtoken;

	if(yylex() != INIMUSICA){
		errorFile << "Syntax ERROR in line: " << yylineno <<   " Expect to start with 'IniMusica' \n";
		errorFile.close();	
		return -1;
	}

	while(true) {
		vtoken = yylex();//printf("current token: %d \n", vtoken );

		//termina el ciclo cuando encuentra el token FinMusica
		if (vtoken ==  FINMUSICA){
			instrFile.close();
			break;
		}
		//muestra error si no encuentra  el token FinMusica
		if (vtoken == 0){
			errorFile << "Syntax ERROR in line: " <<  (yylineno - 1) <<   " Finish with  'FinMusic'\n";
			errorFile.close();
			printf("Syntax ERROR in line %d. Finish with  'FinMusic\n", (yylineno- 1) );
			return -1;
		}
		switch (vtoken) {
			case FUNC:
				lengthNameProcess = (yyleng -2);  //menos los perentecis
 				nameProcess = yytext; // nameProcess.c_str(); //string to char *
				procedimientos.push_back( nameProcess.substr(0, lengthNameProcess) );
				nameProcess = nameProcess.substr(0, lengthNameProcess);
				nameProcess = nameProcess + ".txt";
				currentProcess = nameProcess;
				tempFileFunc.open(nameProcess.c_str());
				if (processFunc() == 0){
					tempFileFunc.close();
					break;
				}else{
					return -1;
				}
			case PRINCIPAL:
				if(principalFunc() == 0){
					break;
				}
				else{
					exit(-1);
				}
		}	
	}
	return 0;
}
