#define SET 1
#define DEF 2
#define PRINCIPAL 3
#define LOOP 4
#define INILOOP 5
#define FINLOOP 6
#define BLAK 7
#define NEG 8
#define CORCH 9
#define SCORCH 10       
#define INICOMP 11
#define FINCOMP 12
#define INIMUSICA 13
#define FINMUSICA 14
#define ENCASO 15
#define CONTRARIO 16
#define FINENCASO 17
#define EJECUTE 18
#define SILENC 19
#define ENTONCES 20
#define INICIO 21
#define FINAL 22
#define NOTA 23
#define NOTA_SOSTENIDA 24
#define ACORDE_MAYOR 25
#define ACORDE_MAYOR_SOSTENIDO 26
#define ACORDE_MENOR 28
#define ACORDE_MENOR_SOSTENIDO 29
#define FUNC 30
#define IDENTIFIER 31
#define NUMBER 32
#define PARENTESIS_IZQ 33
#define PARENTESIS_DER 34


#include <stdlib.h>
#include <stdio.h>
#include <string>
#include <cstring>
#include <vector>
#include <iostream>
#include <fstream>

extern int yylex();
extern int yylineno;
extern char* yytext;
extern int yyleng;
extern FILE *yyin;

using namespace std;

extern std::fstream  ofstream;
extern std::fstream  ifstream;
extern std::string   string;
extern std::vector<void>  vector;